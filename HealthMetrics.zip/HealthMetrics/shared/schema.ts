import { pgTable, text, serial, integer, boolean, timestamp, real, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const healthAssessments = pgTable("health_assessments", {
  id: serial("id").primaryKey(),
  userName: varchar("user_name", { length: 100 }),
  email: varchar("email", { length: 255 }),
  height: real("height"), // in cm
  weight: real("weight"), // in kg
  age: integer("age"),
  gender: varchar("gender", { length: 10 }), // 'male' or 'female'
  waist: real("waist"), // in cm
  neck: real("neck"), // in cm
  hip: real("hip"), // in cm
  restingHeartRate: integer("resting_heart_rate"),
  activityLevel: varchar("activity_level", { length: 20 }),
  
  // Calculated results
  bmi: real("bmi"),
  bmr: real("bmr"),
  bodyFat: real("body_fat"),
  waterIntake: real("water_intake"), // in ml
  idealWeight: real("ideal_weight"), // in kg
  heartRateMax: integer("heart_rate_max"),
  dailyCalories: real("daily_calories"),
  
  // Health categories
  bmiCategory: varchar("bmi_category", { length: 50 }),
  bodyFatCategory: varchar("body_fat_category", { length: 50 }),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const healthGoals = pgTable("health_goals", {
  id: serial("id").primaryKey(),
  assessmentId: integer("assessment_id").references(() => healthAssessments.id),
  goalType: varchar("goal_type", { length: 50 }), // 'weight_loss', 'weight_gain', 'maintain', 'fitness'
  targetWeight: real("target_weight"),
  targetBodyFat: real("target_body_fat"),
  targetDate: timestamp("target_date"),
  notes: text("notes"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const healthAssessmentsRelations = relations(healthAssessments, ({ many }) => ({
  goals: many(healthGoals),
}));

export const healthGoalsRelations = relations(healthGoals, ({ one }) => ({
  assessment: one(healthAssessments, {
    fields: [healthGoals.assessmentId],
    references: [healthAssessments.id],
  }),
}));

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertHealthAssessmentSchema = createInsertSchema(healthAssessments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertHealthGoalSchema = createInsertSchema(healthGoals).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type HealthAssessment = typeof healthAssessments.$inferSelect;
export type InsertHealthAssessment = z.infer<typeof insertHealthAssessmentSchema>;
export type HealthGoal = typeof healthGoals.$inferSelect;
export type InsertHealthGoal = z.infer<typeof insertHealthGoalSchema>;
