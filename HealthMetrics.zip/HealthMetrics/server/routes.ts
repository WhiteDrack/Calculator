import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertHealthAssessmentSchema, insertHealthGoalSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Health Assessment API routes
  app.post("/api/health-assessments", async (req, res) => {
    try {
      const validatedData = insertHealthAssessmentSchema.parse(req.body);
      const assessment = await storage.createHealthAssessment(validatedData);
      res.json(assessment);
    } catch (error) {
      console.error(`Error creating health assessment: ${error}`);
      res.status(400).json({ error: "Invalid assessment data" });
    }
  });

  app.get("/api/health-assessments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const assessment = await storage.getHealthAssessment(id);
      if (!assessment) {
        return res.status(404).json({ error: "Assessment not found" });
      }
      res.json(assessment);
    } catch (error) {
      console.error(`Error fetching health assessment: ${error}`);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/health-assessments/email/:email", async (req, res) => {
    try {
      const email = req.params.email;
      const assessments = await storage.getHealthAssessmentsByEmail(email);
      res.json(assessments);
    } catch (error) {
      console.error(`Error fetching health assessments by email: ${error}`);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.put("/api/health-assessments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertHealthAssessmentSchema.partial().parse(req.body);
      const assessment = await storage.updateHealthAssessment(id, validatedData);
      if (!assessment) {
        return res.status(404).json({ error: "Assessment not found" });
      }
      res.json(assessment);
    } catch (error) {
      console.error(`Error updating health assessment: ${error}`);
      res.status(400).json({ error: "Invalid assessment data" });
    }
  });

  // Health Goals API routes
  app.post("/api/health-goals", async (req, res) => {
    try {
      const validatedData = insertHealthGoalSchema.parse(req.body);
      const goal = await storage.createHealthGoal(validatedData);
      res.json(goal);
    } catch (error) {
      console.error(`Error creating health goal: ${error}`);
      res.status(400).json({ error: "Invalid goal data" });
    }
  });

  app.get("/api/health-goals/assessment/:assessmentId", async (req, res) => {
    try {
      const assessmentId = parseInt(req.params.assessmentId);
      const goals = await storage.getHealthGoalsByAssessment(assessmentId);
      res.json(goals);
    } catch (error) {
      console.error(`Error fetching health goals: ${error}`);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.put("/api/health-goals/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertHealthGoalSchema.partial().parse(req.body);
      const goal = await storage.updateHealthGoal(id, validatedData);
      if (!goal) {
        return res.status(404).json({ error: "Goal not found" });
      }
      res.json(goal);
    } catch (error) {
      console.error(`Error updating health goal: ${error}`);
      res.status(400).json({ error: "Invalid goal data" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
