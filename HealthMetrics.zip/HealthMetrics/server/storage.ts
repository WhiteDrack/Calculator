import { users, healthAssessments, healthGoals, type User, type InsertUser, type HealthAssessment, type InsertHealthAssessment, type HealthGoal, type InsertHealthGoal } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Health Assessment methods
  createHealthAssessment(assessment: InsertHealthAssessment): Promise<HealthAssessment>;
  getHealthAssessment(id: number): Promise<HealthAssessment | undefined>;
  getHealthAssessmentsByEmail(email: string): Promise<HealthAssessment[]>;
  updateHealthAssessment(id: number, assessment: Partial<InsertHealthAssessment>): Promise<HealthAssessment | undefined>;
  
  // Health Goals methods
  createHealthGoal(goal: InsertHealthGoal): Promise<HealthGoal>;
  getHealthGoalsByAssessment(assessmentId: number): Promise<HealthGoal[]>;
  updateHealthGoal(id: number, goal: Partial<InsertHealthGoal>): Promise<HealthGoal | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Health Assessment methods
  async createHealthAssessment(assessment: InsertHealthAssessment): Promise<HealthAssessment> {
    const [newAssessment] = await db
      .insert(healthAssessments)
      .values(assessment)
      .returning();
    return newAssessment;
  }

  async getHealthAssessment(id: number): Promise<HealthAssessment | undefined> {
    const [assessment] = await db
      .select()
      .from(healthAssessments)
      .where(eq(healthAssessments.id, id));
    return assessment || undefined;
  }

  async getHealthAssessmentsByEmail(email: string): Promise<HealthAssessment[]> {
    return await db
      .select()
      .from(healthAssessments)
      .where(eq(healthAssessments.email, email))
      .orderBy(desc(healthAssessments.createdAt));
  }

  async updateHealthAssessment(id: number, assessment: Partial<InsertHealthAssessment>): Promise<HealthAssessment | undefined> {
    const [updatedAssessment] = await db
      .update(healthAssessments)
      .set({ ...assessment, updatedAt: new Date() })
      .where(eq(healthAssessments.id, id))
      .returning();
    return updatedAssessment || undefined;
  }

  // Health Goals methods
  async createHealthGoal(goal: InsertHealthGoal): Promise<HealthGoal> {
    const [newGoal] = await db
      .insert(healthGoals)
      .values(goal)
      .returning();
    return newGoal;
  }

  async getHealthGoalsByAssessment(assessmentId: number): Promise<HealthGoal[]> {
    return await db
      .select()
      .from(healthGoals)
      .where(eq(healthGoals.assessmentId, assessmentId))
      .orderBy(desc(healthGoals.createdAt));
  }

  async updateHealthGoal(id: number, goal: Partial<InsertHealthGoal>): Promise<HealthGoal | undefined> {
    const [updatedGoal] = await db
      .update(healthGoals)
      .set(goal)
      .where(eq(healthGoals.id, id))
      .returning();
    return updatedGoal || undefined;
  }
}

export const storage = new DatabaseStorage();
