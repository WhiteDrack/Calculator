import { Link } from "wouter";
import { LucideIcon } from "lucide-react";
import { ArrowRight } from "lucide-react";

interface CalculatorCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  href: string;
  color: string;
}

export default function CalculatorCard({ title, description, icon: Icon, href, color }: CalculatorCardProps) {
  return (
    <Link href={href}>
      <div className="health-card group">
        <div className={`health-card-icon bg-gradient-to-br ${color}`}>
          <Icon className="h-8 w-8" />
        </div>
        <h3 className="text-xl font-semibold text-slate-800 mb-2">{title}</h3>
        <p className="text-slate-600 text-sm mb-4">{description}</p>
        <div className="flex items-center text-primary text-sm font-medium">
          <span>Calculate Now</span>
          <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </Link>
  );
}
