import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, FileText, TrendingUp, Heart, Target } from "lucide-react";
import { Line, Doughnut, Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  BarElement,
} from "chart.js";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  BarElement
);

interface HealthData {
  bmi?: number;
  bmr?: number;
  bodyFat?: number;
  waterIntake?: number;
  idealWeight?: number;
  heartRateMax?: number;
  calories?: number;
  height?: number;
  weight?: number;
  age?: number;
  gender?: "male" | "female";
}

interface HealthReportProps {
  healthData: HealthData;
  userName?: string;
}

export default function HealthReport({ healthData, userName = "User" }: HealthReportProps) {
  const [isGenerating, setIsGenerating] = useState(false);

  const generateRecommendations = () => {
    const recommendations = [];
    
    // BMI-based recommendations
    if (healthData.bmi) {
      if (healthData.bmi < 18.5) {
        recommendations.push({
          category: "Nutrition",
          title: "Healthy Weight Gain",
          items: [
            "Include protein-rich foods like nuts, seeds, and lean meats",
            "Add healthy fats from avocados, olive oil, and fish",
            "Eat frequent, smaller meals throughout the day",
            "Consider strength training to build muscle mass"
          ]
        });
      } else if (healthData.bmi > 25) {
        recommendations.push({
          category: "Nutrition",
          title: "Healthy Weight Management",
          items: [
            "Focus on whole foods: vegetables, fruits, lean proteins",
            "Control portion sizes and practice mindful eating",
            "Limit processed foods and added sugars",
            "Stay hydrated and drink water before meals"
          ]
        });
      } else {
        recommendations.push({
          category: "Nutrition",
          title: "Maintain Healthy Weight",
          items: [
            "Continue balanced diet with variety of nutrients",
            "Maintain current eating patterns that work for you",
            "Include seasonal fruits and vegetables",
            "Stay consistent with meal timing"
          ]
        });
      }
    }

    // Exercise recommendations based on BMR and fitness goals
    if (healthData.bmr) {
      recommendations.push({
        category: "Exercise",
        title: "Personalized Fitness Plan",
        items: [
          "Aim for 150 minutes moderate cardio per week",
          "Include 2-3 strength training sessions weekly",
          "Add flexibility work: yoga or stretching daily",
          "Start with 30-minute walks if new to exercise"
        ]
      });
    }

    // Heart rate training zones
    if (healthData.heartRateMax) {
      recommendations.push({
        category: "Cardio Training",
        title: "Heart Rate Zone Training",
        items: [
          `Fat burning zone: ${Math.round(healthData.heartRateMax * 0.6)}-${Math.round(healthData.heartRateMax * 0.7)} bpm`,
          `Aerobic zone: ${Math.round(healthData.heartRateMax * 0.7)}-${Math.round(healthData.heartRateMax * 0.8)} bpm`,
          "Use a fitness tracker to monitor your heart rate",
          "Spend 80% of training time in lower intensity zones"
        ]
      });
    }

    // Water intake recommendations
    if (healthData.waterIntake) {
      recommendations.push({
        category: "Hydration",
        title: "Daily Water Goals",
        items: [
          `Target: ${(healthData.waterIntake / 1000).toFixed(1)}L of water daily`,
          "Drink a glass of water upon waking",
          "Carry a water bottle throughout the day",
          "Increase intake during exercise and hot weather"
        ]
      });
    }

    return recommendations;
  };

  const getBMIChart = () => {
    if (!healthData.bmi) return null;

    const data = {
      labels: ['Underweight', 'Normal', 'Overweight', 'Obese'],
      datasets: [
        {
          data: [18.5, 6.4, 4.1, 10],
          backgroundColor: [
            '#3B82F6',
            '#10B981',
            '#F59E0B',
            '#EF4444',
          ],
          borderWidth: 2,
          borderColor: '#fff',
        },
      ],
    };

    const options = {
      responsive: true,
      plugins: {
        legend: {
          position: 'bottom' as const,
        },
        title: {
          display: true,
          text: `Your BMI: ${healthData.bmi.toFixed(1)}`,
        },
      },
    };

    return <Doughnut data={data} options={options} />;
  };

  const getProgressChart = () => {
    const data = {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
      datasets: [
        {
          label: 'Weight Trend',
          data: [
            healthData.weight ? healthData.weight + 2 : 70,
            healthData.weight ? healthData.weight + 1 : 69,
            healthData.weight ? healthData.weight + 0.5 : 68.5,
            healthData.weight ? healthData.weight : 68,
            healthData.weight ? healthData.weight - 0.5 : 67.5,
            healthData.weight ? healthData.weight - 1 : 67,
          ],
          borderColor: 'rgb(75, 192, 192)',
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          tension: 0.1,
        },
      ],
    };

    const options = {
      responsive: true,
      plugins: {
        legend: {
          position: 'top' as const,
        },
        title: {
          display: true,
          text: 'Weight Progress Tracking',
        },
      },
      scales: {
        y: {
          beginAtZero: false,
        },
      },
    };

    return <Line data={data} options={options} />;
  };

  const getMetricsChart = () => {
    const metrics = [];
    const values = [];
    const colors = [];

    if (healthData.bmi) {
      metrics.push('BMI');
      values.push(healthData.bmi);
      colors.push('#8B5CF6');
    }
    if (healthData.bodyFat) {
      metrics.push('Body Fat %');
      values.push(healthData.bodyFat);
      colors.push('#06B6D4');
    }
    if (healthData.bmr) {
      metrics.push('BMR/100');
      values.push(healthData.bmr / 100);
      colors.push('#10B981');
    }

    const data = {
      labels: metrics,
      datasets: [
        {
          label: 'Health Metrics',
          data: values,
          backgroundColor: colors,
          borderColor: colors.map(color => color),
          borderWidth: 1,
        },
      ],
    };

    const options = {
      responsive: true,
      plugins: {
        legend: {
          display: false,
        },
        title: {
          display: true,
          text: 'Your Health Metrics',
        },
      },
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    };

    return <Bar data={data} options={options} />;
  };

  const generatePDF = async () => {
    setIsGenerating(true);
    try {
      const element = document.getElementById('health-report');
      if (!element) return;

      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`${userName}_Health_Report_${new Date().toISOString().split('T')[0]}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Error generating PDF. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const recommendations = generateRecommendations();

  return (
    <Card className="mt-8">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-6 w-6 text-primary" />
          Personal Health Report
        </CardTitle>
        <CardDescription>
          Comprehensive analysis with personalized recommendations
        </CardDescription>
        <Button 
          onClick={generatePDF} 
          disabled={isGenerating}
          className="w-fit"
        >
          <Download className="mr-2 h-4 w-4" />
          {isGenerating ? 'Generating...' : 'Download PDF Report'}
        </Button>
      </CardHeader>

      <CardContent>
        <div id="health-report" className="space-y-8 p-6 bg-white">
          {/* Header */}
          <div className="text-center border-b pb-6">
            <h1 className="text-3xl font-bold text-slate-800 mb-2">
              Health Assessment Report
            </h1>
            <p className="text-lg text-slate-600">Generated for {userName}</p>
            <p className="text-sm text-slate-500">
              Date: {new Date().toLocaleDateString()}
            </p>
          </div>

          {/* Health Metrics Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {healthData.bmi && (
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{healthData.bmi.toFixed(1)}</div>
                <div className="text-sm text-slate-600">BMI</div>
              </div>
            )}
            {healthData.bmr && (
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{Math.round(healthData.bmr)}</div>
                <div className="text-sm text-slate-600">BMR (cal/day)</div>
              </div>
            )}
            {healthData.bodyFat && (
              <div className="text-center p-4 bg-amber-50 rounded-lg">
                <div className="text-2xl font-bold text-amber-600">{healthData.bodyFat.toFixed(1)}%</div>
                <div className="text-sm text-slate-600">Body Fat</div>
              </div>
            )}
            {healthData.waterIntake && (
              <div className="text-center p-4 bg-cyan-50 rounded-lg">
                <div className="text-2xl font-bold text-cyan-600">{(healthData.waterIntake / 1000).toFixed(1)}L</div>
                <div className="text-sm text-slate-600">Daily Water</div>
              </div>
            )}
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {healthData.bmi && (
              <div className="bg-slate-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold mb-4">BMI Analysis</h3>
                <div className="h-64">
                  {getBMIChart()}
                </div>
              </div>
            )}
            
            <div className="bg-slate-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold mb-4">Health Metrics Overview</h3>
              <div className="h-64">
                {getMetricsChart()}
              </div>
            </div>

            <div className="bg-slate-50 p-6 rounded-lg lg:col-span-2">
              <h3 className="text-lg font-semibold mb-4">Progress Tracking</h3>
              <div className="h-64">
                {getProgressChart()}
              </div>
            </div>
          </div>

          {/* Personalized Recommendations */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
              <Target className="h-6 w-6 text-primary" />
              Personalized Recommendations
            </h3>
            
            {recommendations.map((rec, index) => (
              <div key={index} className="bg-gradient-to-r from-primary/5 to-secondary/5 p-6 rounded-lg">
                <h4 className="text-lg font-semibold text-slate-800 mb-3 flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  {rec.category}: {rec.title}
                </h4>
                <ul className="space-y-2">
                  {rec.items.map((item, itemIndex) => (
                    <li key={itemIndex} className="flex items-start gap-2 text-slate-700">
                      <span className="text-primary mt-1">•</span>
                      <span className="text-sm">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Health Goals */}
          <div className="bg-slate-50 p-6 rounded-lg">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              30-Day Health Goals
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium text-slate-800 mb-2">Fitness Goals</h4>
                <ul className="text-sm text-slate-600 space-y-1">
                  <li>• Exercise 4-5 times per week</li>
                  <li>• Track daily steps (aim for 8,000+)</li>
                  <li>• Include 2 strength training sessions</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium text-slate-800 mb-2">Wellness Goals</h4>
                <ul className="text-sm text-slate-600 space-y-1">
                  <li>• Maintain consistent sleep schedule</li>
                  <li>• Practice stress management techniques</li>
                  <li>• Regular health metric tracking</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center text-sm text-slate-500 border-t pt-4">
            <p>This report is for informational purposes only. Please consult healthcare professionals for medical advice.</p>
            <p className="mt-2">Generated by HealthCalc Pro | {new Date().toLocaleDateString()}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}