import { Link } from "wouter";
import CalculatorCard from "@/components/calculator-card";
import {
  Weight,
  Flame,
  Utensils,
  Scale,
  Activity,
  Droplets,
  Baby,
  Heart,
  Calculator,
  Play,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  FileText,
  TrendingUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  const calculators = [
    {
      title: "BMI Calculator",
      description: "Calculate your Body Mass Index and health category",
      icon: Weight,
      href: "/calculator/bmi",
      color: "from-blue-500 to-blue-600",
    },
    {
      title: "BMR Calculator",
      description: "Find your Basal Metabolic Rate for daily calories",
      icon: Flame,
      href: "/calculator/bmr",
      color: "from-green-500 to-green-600",
    },
    {
      title: "Calorie Calculator",
      description: "Calculate daily calorie needs for your goals",
      icon: Utensils,
      href: "/calculator/calorie",
      color: "from-purple-500 to-purple-600",
    },
    {
      title: "Ideal Weight",
      description: "Find your ideal weight using multiple formulas",
      icon: Scale,
      href: "/calculator/ideal-weight",
      color: "from-emerald-500 to-emerald-600",
    },
    {
      title: "Body Fat %",
      description: "Calculate body fat percentage accurately",
      icon: Activity,
      href: "/calculator/body-fat",
      color: "from-amber-500 to-amber-600",
    },
    {
      title: "Water Intake",
      description: "Calculate optimal daily water consumption",
      icon: Droplets,
      href: "/calculator/water",
      color: "from-blue-400 to-blue-500",
    },
    {
      title: "Due Date",
      description: "Calculate pregnancy due date and milestones",
      icon: Baby,
      href: "/calculator/pregnancy",
      color: "from-pink-500 to-pink-600",
    },
    {
      title: "Heart Rate Zones",
      description: "Calculate target heart rate zones for exercise",
      icon: Heart,
      href: "/calculator/heart-rate",
      color: "from-red-500 to-red-600",
    },
  ];

  const handleScrollToCalculators = () => {
    document.getElementById("calculators")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section id="home" className="relative bg-gradient-to-br from-primary/10 via-secondary/5 to-accent/10 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-slate-800 mb-6">
              Check Your Health{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
                Instantly
              </span>
            </h1>
            <p className="text-xl text-slate-600 mb-8 max-w-3xl mx-auto">
              Professional-grade health calculators trusted by healthcare professionals. 
              Get accurate BMI, BMR, calorie needs, and more with our comprehensive suite of tools.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/health-dashboard">
                <Button
                  size="lg"
                  className="gradient-primary text-white px-8 py-4 rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200 w-full sm:w-auto"
                >
                  <FileText className="mr-2 h-5 w-5" />
                  Complete Health Report
                </Button>
              </Link>
              <Button
                size="lg"
                className="border-2 border-primary text-primary px-8 py-4 rounded-xl font-semibold hover:bg-primary hover:text-white transition-all duration-200"
                onClick={handleScrollToCalculators}
              >
                <Calculator className="mr-2 h-5 w-5" />
                Individual Calculators
              </Button>
            </div>
          </div>
        </div>

        {/* Floating Health Icons */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-10 text-primary/20 text-4xl animate-pulse">
            <Heart className="h-10 w-10" />
          </div>
          <div className="absolute top-40 right-20 text-secondary/20 text-3xl animate-pulse" style={{animationDelay: '1s'}}>
            <Weight className="h-8 w-8" />
          </div>
          <div className="absolute bottom-20 left-20 text-accent/20 text-3xl animate-pulse" style={{animationDelay: '2s'}}>
            <Activity className="h-8 w-8" />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gradient-to-br from-slate-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">Complete Health Assessment</h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Get a comprehensive health analysis with personalized recommendations and downloadable PDF reports
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
            <div className="text-center p-8 bg-white rounded-2xl shadow-lg">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Calculator className="text-white h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold text-slate-800 mb-4">8 Health Calculators</h3>
              <p className="text-slate-600">
                BMI, BMR, Body Fat, Calorie Needs, Ideal Weight, Water Intake, Pregnancy, and Heart Rate Zones
              </p>
            </div>

            <div className="text-center p-8 bg-white rounded-2xl shadow-lg">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <TrendingUp className="text-white h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold text-slate-800 mb-4">Smart Recommendations</h3>
              <p className="text-slate-600">
                Personalized diet plans, exercise routines, and wellness goals based on your health metrics
              </p>
            </div>

            <div className="text-center p-8 bg-white rounded-2xl shadow-lg">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <FileText className="text-white h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold text-slate-800 mb-4">PDF Health Reports</h3>
              <p className="text-slate-600">
                Download comprehensive health reports with charts, analysis, and personalized recommendations
              </p>
            </div>
          </div>

          <div className="text-center">
            <Link href="/health-dashboard">
              <Button
                size="lg"
                className="gradient-primary text-white px-12 py-4 rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
              >
                <FileText className="mr-2 h-6 w-6" />
                Try Complete Health Assessment
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Calculators Grid */}
      <section id="calculators" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">Individual Health Calculators</h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Choose from our comprehensive collection of medically accurate health assessment tools
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {calculators.map((calculator) => (
              <CalculatorCard
                key={calculator.href}
                title={calculator.title}
                description={calculator.description}
                icon={calculator.icon}
                href={calculator.href}
                color={calculator.color}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Logo and Description */}
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
                  <Heart className="text-white h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">HealthCalc Pro</h3>
                  <p className="text-sm text-slate-400">Professional Health Tools</p>
                </div>
              </div>
              <p className="text-slate-400 mb-4 max-w-md">
                Empowering individuals with accurate, professional-grade health calculators for better wellness decisions.
              </p>
              <div className="flex space-x-4">
                <Button size="icon" variant="ghost" className="w-10 h-10 bg-slate-700 rounded-lg hover:bg-primary">
                  <Facebook className="h-5 w-5" />
                </Button>
                <Button size="icon" variant="ghost" className="w-10 h-10 bg-slate-700 rounded-lg hover:bg-primary">
                  <Twitter className="h-5 w-5" />
                </Button>
                <Button size="icon" variant="ghost" className="w-10 h-10 bg-slate-700 rounded-lg hover:bg-primary">
                  <Linkedin className="h-5 w-5" />
                </Button>
                <Button size="icon" variant="ghost" className="w-10 h-10 bg-slate-700 rounded-lg hover:bg-primary">
                  <Instagram className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-slate-400">
                <li><Link href="/" className="hover:text-white transition-colors">Home</Link></li>
                <li><a href="#calculators" className="hover:text-white transition-colors">Calculators</a></li>
                <li><a href="#about" className="hover:text-white transition-colors">About Us</a></li>
                <li><a href="#contact" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-slate-400">
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Disclaimer</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Support</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-700 mt-8 pt-8 text-center text-slate-400">
            <p>&copy; 2024 HealthCalc Pro. All rights reserved. | Made with <Heart className="inline h-4 w-4 text-red-500" /> for better health</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
