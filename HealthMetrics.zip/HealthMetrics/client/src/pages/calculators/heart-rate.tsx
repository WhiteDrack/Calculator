import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Heart, Calculator, Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { calculateHeartRateZones } from "@/lib/calculations";
import type { HeartRateResult } from "@/lib/calculations";

export default function HeartRateCalculator() {
  const [age, setAge] = useState("");
  const [restingHR, setRestingHR] = useState("60");
  const [result, setResult] = useState<HeartRateResult | null>(null);

  const handleCalculate = () => {
    try {
      const ageNum = parseFloat(age);
      const restingHRNum = parseFloat(restingHR);

      if (ageNum > 0 && ageNum < 120 && restingHRNum > 0 && restingHRNum < 200) {
        const hrResult = calculateHeartRateZones(ageNum, restingHRNum);
        setResult(hrResult);
      } else {
        alert("Please enter valid age (1-120) and resting heart rate (1-200) values.");
      }
    } catch (error) {
      alert("Please enter valid numeric values.");
    }
  };

  const zones = [
    {
      name: "Warm-up Zone",
      key: "warmup" as keyof HeartRateResult["zones"],
      intensity: "50-60%",
      description: "Light intensity, conversation pace",
      color: "bg-gray-50 border-gray-200 text-gray-700",
      benefits: "Active recovery, warm-up"
    },
    {
      name: "Fat Burn Zone",
      key: "fatBurn" as keyof HeartRateResult["zones"],
      intensity: "60-70%",
      description: "Moderate intensity, comfortable pace",
      color: "bg-green-50 border-green-200 text-green-700",
      benefits: "Fat burning, base fitness"
    },
    {
      name: "Aerobic Zone",
      key: "aerobic" as keyof HeartRateResult["zones"],
      intensity: "70-80%",
      description: "Hard intensity, challenging pace",
      color: "bg-blue-50 border-blue-200 text-blue-700",
      benefits: "Cardiovascular fitness"
    },
    {
      name: "Anaerobic Zone",
      key: "anaerobic" as keyof HeartRateResult["zones"],
      intensity: "80-90%",
      description: "Very hard intensity, short bursts",
      color: "bg-orange-50 border-orange-200 text-orange-700",
      benefits: "Performance improvement"
    },
    {
      name: "Redline Zone",
      key: "redline" as keyof HeartRateResult["zones"],
      intensity: "90-100%",
      description: "Maximum intensity, sprint pace",
      color: "bg-red-50 border-red-200 text-red-700",
      benefits: "Peak performance training"
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link href="/">
          <Button variant="ghost" className="mb-8 text-slate-600 hover:text-primary">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Calculators
          </Button>
        </Link>

        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-red-500 to-red-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Heart className="text-white h-10 w-10" />
            </div>
            <CardTitle className="text-3xl font-bold text-slate-800">Heart Rate Zone Calculator</CardTitle>
            <CardDescription className="text-lg">
              Calculate your target heart rate zones for optimal exercise
            </CardDescription>
          </CardHeader>

          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Input Section */}
              <div className="space-y-6">
                {/* Age Input */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Age</Label>
                  <div className="relative mt-2">
                    <Input
                      type="number"
                      placeholder="25"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      className="pr-16"
                      min="1"
                      max="120"
                    />
                    <span className="absolute right-4 top-3 text-slate-500 text-sm">years</span>
                  </div>
                </div>

                {/* Resting Heart Rate Input */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Resting Heart Rate</Label>
                  <div className="relative mt-2">
                    <Input
                      type="number"
                      placeholder="60"
                      value={restingHR}
                      onChange={(e) => setRestingHR(e.target.value)}
                      className="pr-16"
                      min="30"
                      max="200"
                    />
                    <span className="absolute right-4 top-3 text-slate-500 text-sm">bpm</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Measure first thing in the morning before getting out of bed
                  </p>
                </div>

                {/* Calculate Button */}
                <Button
                  onClick={handleCalculate}
                  className="w-full gradient-primary text-white py-3 rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
                >
                  <Calculator className="mr-2 h-5 w-5" />
                  Calculate Heart Rate Zones
                </Button>

                {/* How to Measure */}
                <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
                  <h4 className="font-semibold text-slate-700 mb-2">How to Measure Resting HR</h4>
                  <ul className="text-sm text-slate-600 space-y-1">
                    <li>• Place two fingers on your wrist or neck</li>
                    <li>• Count beats for 15 seconds and multiply by 4</li>
                    <li>• Measure first thing in the morning</li>
                    <li>• Take several readings for accuracy</li>
                  </ul>
                </div>
              </div>

              {/* Results Section */}
              <div className="space-y-6">
                {result && (
                  <>
                    {/* Maximum Heart Rate */}
                    <div className="text-center p-6 bg-slate-50 rounded-2xl">
                      <h3 className="text-lg font-semibold text-slate-700 mb-2">Maximum Heart Rate</h3>
                      <div className="text-4xl font-bold text-red-600 mb-2">{result.maxHR}</div>
                      <p className="text-sm text-slate-600">beats per minute</p>
                    </div>

                    {/* Heart Rate Zones */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-slate-700">Training Zones</h4>
                      <div className="space-y-3">
                        {zones.map((zone) => (
                          <div
                            key={zone.key}
                            className={`p-4 rounded-xl border ${zone.color}`}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <div>
                                <div className="font-semibold text-sm">{zone.name}</div>
                                <div className="text-xs opacity-75">{zone.intensity} of max HR</div>
                              </div>
                              <div className="text-right">
                                <div className="font-bold text-lg">
                                  {result.zones[zone.key].min}-{result.zones[zone.key].max}
                                </div>
                                <div className="text-xs">bpm</div>
                              </div>
                            </div>
                            <div className="text-xs mb-1">{zone.description}</div>
                            <div className="text-xs font-medium">Benefits: {zone.benefits}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}

                {/* Health Tips */}
                <div className="p-6 gradient-card rounded-2xl">
                  <h4 className="font-semibold text-slate-700 mb-3 flex items-center">
                    <Lightbulb className="text-yellow-500 mr-2 h-5 w-5" />
                    Training Tips
                  </h4>
                  <div className="text-sm text-slate-600 space-y-2">
                    <p>• Spend 80% of training time in aerobic zones (Zone 1-3)</p>
                    <p>• Use anaerobic zones for interval training</p>
                    <p>• Monitor heart rate during exercise with a fitness tracker</p>
                    <p>• Allow adequate recovery between high-intensity sessions</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
