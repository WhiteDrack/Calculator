import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Flame, Calculator, Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import UnitToggle from "@/components/unit-toggle";
import { calculateBMR, convertHeight, convertWeight, convertCmToMeters } from "@/lib/calculations";
import type { BMRResult } from "@/lib/calculations";

export default function BMRCalculator() {
  const [isMetric, setIsMetric] = useState(true);
  const [height, setHeight] = useState("");
  const [heightFt, setHeightFt] = useState("");
  const [heightIn, setHeightIn] = useState("");
  const [weight, setWeight] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState<"male" | "female">("male");
  const [result, setResult] = useState<BMRResult | null>(null);

  const handleCalculate = () => {
    let heightInMeters: number;
    let weightInKg: number;

    try {
      if (isMetric) {
        heightInMeters = convertCmToMeters(parseFloat(height));
        weightInKg = parseFloat(weight);
      } else {
        heightInMeters = convertHeight(parseFloat(heightFt), parseFloat(heightIn));
        weightInKg = convertWeight(parseFloat(weight));
      }

      const ageNum = parseFloat(age);

      if (heightInMeters > 0 && weightInKg > 0 && ageNum > 0) {
        const bmrResult = calculateBMR(weightInKg, heightInMeters, ageNum, gender);
        setResult(bmrResult);
      } else {
        alert("Please enter valid height, weight, and age values.");
      }
    } catch (error) {
      alert("Please enter valid numeric values.");
    }
  };

  const activityLevels = [
    { label: "Sedentary", description: "Little or no exercise", key: "sedentary" },
    { label: "Light", description: "Light exercise 1-3 days/week", key: "light" },
    { label: "Moderate", description: "Moderate exercise 3-5 days/week", key: "moderate" },
    { label: "Active", description: "Hard exercise 6-7 days/week", key: "active" },
    { label: "Very Active", description: "Very hard exercise, physical job", key: "veryActive" },
  ];

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link href="/">
          <Button variant="ghost" className="mb-8 text-slate-600 hover:text-primary">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Calculators
          </Button>
        </Link>

        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Flame className="text-white h-10 w-10" />
            </div>
            <CardTitle className="text-3xl font-bold text-slate-800">BMR Calculator</CardTitle>
            <CardDescription className="text-lg">
              Find your Basal Metabolic Rate and daily calorie needs
            </CardDescription>
          </CardHeader>

          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Input Section */}
              <div className="space-y-6">
                <UnitToggle isMetric={isMetric} onToggle={setIsMetric} />

                {/* Gender Selection */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Gender</Label>
                  <Select value={gender} onValueChange={(value) => setGender(value as "male" | "female")}>
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Age Input */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Age</Label>
                  <div className="relative mt-2">
                    <Input
                      type="number"
                      placeholder="25"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      className="pr-16"
                    />
                    <span className="absolute right-4 top-3 text-slate-500 text-sm">years</span>
                  </div>
                </div>

                {/* Height Input */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Height</Label>
                  {isMetric ? (
                    <div className="relative mt-2">
                      <Input
                        type="number"
                        placeholder="175"
                        value={height}
                        onChange={(e) => setHeight(e.target.value)}
                        className="pr-12"
                      />
                      <span className="absolute right-4 top-3 text-slate-500 text-sm">cm</span>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-3 mt-2">
                      <div className="relative">
                        <Input
                          type="number"
                          placeholder="5"
                          value={heightFt}
                          onChange={(e) => setHeightFt(e.target.value)}
                          className="pr-8"
                        />
                        <span className="absolute right-3 top-3 text-slate-500 text-sm">ft</span>
                      </div>
                      <div className="relative">
                        <Input
                          type="number"
                          placeholder="9"
                          value={heightIn}
                          onChange={(e) => setHeightIn(e.target.value)}
                          className="pr-8"
                        />
                        <span className="absolute right-3 top-3 text-slate-500 text-sm">in</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Weight Input */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Weight</Label>
                  <div className="relative mt-2">
                    <Input
                      type="number"
                      placeholder={isMetric ? "70" : "154"}
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      className="pr-12"
                    />
                    <span className="absolute right-4 top-3 text-slate-500 text-sm">
                      {isMetric ? "kg" : "lbs"}
                    </span>
                  </div>
                </div>

                {/* Calculate Button */}
                <Button
                  onClick={handleCalculate}
                  className="w-full gradient-primary text-white py-3 rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
                >
                  <Calculator className="mr-2 h-5 w-5" />
                  Calculate BMR
                </Button>
              </div>

              {/* Results Section */}
              <div className="space-y-6">
                {result && (
                  <>
                    {/* BMR Score */}
                    <div className="text-center p-6 bg-slate-50 rounded-2xl">
                      <h3 className="text-lg font-semibold text-slate-700 mb-2">Your BMR</h3>
                      <div className="text-4xl font-bold text-green-600 mb-2">
                        {Math.round(result.bmr)}
                      </div>
                      <p className="text-sm text-slate-600">calories per day</p>
                    </div>

                    {/* Activity Levels */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-slate-700">Daily Calorie Needs</h4>
                      <div className="space-y-2">
                        {activityLevels.map((level) => (
                          <div
                            key={level.key}
                            className="flex items-center justify-between p-4 rounded-lg bg-green-50 border border-green-100"
                          >
                            <div>
                              <div className="text-sm font-medium text-slate-800">{level.label}</div>
                              <div className="text-xs text-slate-600">{level.description}</div>
                            </div>
                            <div className="text-lg font-semibold text-green-600">
                              {Math.round(result.calories[level.key as keyof typeof result.calories])}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Health Tips */}
                    <div className="p-6 gradient-card rounded-2xl">
                      <h4 className="font-semibold text-slate-700 mb-3 flex items-center">
                        <Lightbulb className="text-yellow-500 mr-2 h-5 w-5" />
                        About BMR
                      </h4>
                      <p className="text-sm text-slate-600">
                        Your BMR represents the minimum calories your body needs to function at rest. 
                        Choose the activity level that best matches your lifestyle to determine your daily calorie needs.
                      </p>
                    </div>
                  </>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
