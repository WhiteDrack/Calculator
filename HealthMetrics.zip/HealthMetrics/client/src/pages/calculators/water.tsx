import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Droplets, Calculator, Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import UnitToggle from "@/components/unit-toggle";
import { calculateWaterIntake, convertWeight } from "@/lib/calculations";
import type { WaterResult } from "@/lib/calculations";

export default function WaterCalculator() {
  const [isMetric, setIsMetric] = useState(true);
  const [weight, setWeight] = useState("");
  const [activityMinutes, setActivityMinutes] = useState("");
  const [climate, setClimate] = useState<"normal" | "hot" | "humid">("normal");
  const [result, setResult] = useState<WaterResult | null>(null);

  const handleCalculate = () => {
    try {
      let weightInKg: number;

      if (isMetric) {
        weightInKg = parseFloat(weight);
      } else {
        weightInKg = convertWeight(parseFloat(weight));
      }

      const activityMins = parseFloat(activityMinutes) || 0;

      if (weightInKg > 0) {
        const waterResult = calculateWaterIntake(weightInKg, activityMins, climate);
        setResult(waterResult);
      } else {
        alert("Please enter a valid weight value.");
      }
    } catch (error) {
      alert("Please enter valid numeric values.");
    }
  };

  const formatVolume = (ml: number) => {
    if (isMetric) {
      if (ml >= 1000) {
        return `${(ml / 1000).toFixed(1)} L`;
      }
      return `${Math.round(ml)} ml`;
    } else {
      const flOz = ml * 0.033814;
      if (flOz >= 32) {
        return `${(flOz / 32).toFixed(1)} qt`;
      }
      return `${flOz.toFixed(1)} fl oz`;
    }
  };

  const climateOptions = [
    { value: "normal", label: "Normal", description: "Comfortable temperature" },
    { value: "hot", label: "Hot", description: "High temperature environment" },
    { value: "humid", label: "Humid", description: "High humidity environment" },
  ];

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link href="/">
          <Button variant="ghost" className="mb-8 text-slate-600 hover:text-primary">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Calculators
          </Button>
        </Link>

        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-400 to-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Droplets className="text-white h-10 w-10" />
            </div>
            <CardTitle className="text-3xl font-bold text-slate-800">Water Intake Calculator</CardTitle>
            <CardDescription className="text-lg">
              Calculate your optimal daily water consumption needs
            </CardDescription>
          </CardHeader>

          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Input Section */}
              <div className="space-y-6">
                <UnitToggle isMetric={isMetric} onToggle={setIsMetric} />

                {/* Weight Input */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Weight</Label>
                  <div className="relative mt-2">
                    <Input
                      type="number"
                      placeholder={isMetric ? "70" : "154"}
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      className="pr-12"
                    />
                    <span className="absolute right-4 top-3 text-slate-500 text-sm">
                      {isMetric ? "kg" : "lbs"}
                    </span>
                  </div>
                </div>

                {/* Activity Input */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Physical Activity</Label>
                  <div className="relative mt-2">
                    <Input
                      type="number"
                      placeholder="60"
                      value={activityMinutes}
                      onChange={(e) => setActivityMinutes(e.target.value)}
                      className="pr-20"
                    />
                    <span className="absolute right-4 top-3 text-slate-500 text-sm">min/day</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">Average daily exercise time</p>
                </div>

                {/* Climate Selection */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Climate</Label>
                  <Select value={climate} onValueChange={(value) => setClimate(value as "normal" | "hot" | "humid")}>
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {climateOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label} - {option.description}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Calculate Button */}
                <Button
                  onClick={handleCalculate}
                  className="w-full gradient-primary text-white py-3 rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
                >
                  <Calculator className="mr-2 h-5 w-5" />
                  Calculate Water Intake
                </Button>
              </div>

              {/* Results Section */}
              <div className="space-y-6">
                {result && (
                  <>
                    {/* Daily Water Intake */}
                    <div className="text-center p-6 bg-slate-50 rounded-2xl">
                      <h3 className="text-lg font-semibold text-slate-700 mb-2">Daily Water Intake</h3>
                      <div className="text-4xl font-bold text-blue-500 mb-2">
                        {formatVolume(result.daily)}
                      </div>
                      <p className="text-sm text-slate-600">per day</p>
                    </div>

                    {/* Hourly Intake */}
                    <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-slate-700">Hourly Goal</span>
                        <span className="text-lg font-semibold text-blue-600">
                          {formatVolume(result.hourly)}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1">
                        Spread throughout 16 waking hours
                      </p>
                    </div>

                    {/* Water Sources */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-slate-700">Hydration Sources</h4>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50">
                          <span className="text-sm font-medium">Plain Water</span>
                          <span className="text-sm text-slate-600">80%</span>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-green-50">
                          <span className="text-sm font-medium">Fruits & Vegetables</span>
                          <span className="text-sm text-slate-600">15%</span>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50">
                          <span className="text-sm font-medium">Other Beverages</span>
                          <span className="text-sm text-slate-600">5%</span>
                        </div>
                      </div>
                    </div>

                    {/* Health Tips */}
                    <div className="p-6 gradient-card rounded-2xl">
                      <h4 className="font-semibold text-slate-700 mb-3 flex items-center">
                        <Lightbulb className="text-yellow-500 mr-2 h-5 w-5" />
                        Hydration Tips
                      </h4>
                      <p className="text-sm text-slate-600 mb-2">{result.tips}</p>
                      <p className="text-sm text-slate-600">
                        Monitor your urine color - pale yellow indicates good hydration.
                      </p>
                    </div>
                  </>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
