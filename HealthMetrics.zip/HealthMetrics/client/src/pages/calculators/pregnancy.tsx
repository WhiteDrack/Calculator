import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Baby, Calculator, Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { calculatePregnancy } from "@/lib/calculations";
import type { PregnancyResult } from "@/lib/calculations";

export default function PregnancyCalculator() {
  const [lastPeriodDate, setLastPeriodDate] = useState("");
  const [result, setResult] = useState<PregnancyResult | null>(null);

  const handleCalculate = () => {
    try {
      if (!lastPeriodDate) {
        alert("Please enter the date of your last menstrual period.");
        return;
      }

      const lastPeriod = new Date(lastPeriodDate);
      const today = new Date();

      if (lastPeriod > today) {
        alert("The last menstrual period date cannot be in the future.");
        return;
      }

      const pregnancyResult = calculatePregnancy(lastPeriod);
      setResult(pregnancyResult);
    } catch (error) {
      alert("Please enter a valid date.");
    }
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const getTrimesterInfo = (trimester: number) => {
    switch (trimester) {
      case 1:
        return {
          title: "First Trimester",
          weeks: "Weeks 1-12",
          description: "Early pregnancy development and morning sickness may occur",
          color: "bg-pink-50 border-pink-200",
        };
      case 2:
        return {
          title: "Second Trimester",
          weeks: "Weeks 13-27",
          description: "Often called the 'golden period' with increased energy",
          color: "bg-purple-50 border-purple-200",
        };
      case 3:
        return {
          title: "Third Trimester",
          weeks: "Weeks 28-40",
          description: "Final stretch with rapid baby growth and preparation for birth",
          color: "bg-blue-50 border-blue-200",
        };
      default:
        return {
          title: "Pre-pregnancy",
          weeks: "",
          description: "Please check your calculation",
          color: "bg-gray-50 border-gray-200",
        };
    }
  };

  const milestones = [
    { week: 4, event: "Missed period" },
    { week: 8, event: "First prenatal visit" },
    { week: 12, event: "End of first trimester" },
    { week: 16, event: "Gender may be determined" },
    { week: 20, event: "Anatomy scan" },
    { week: 24, event: "Viability milestone" },
    { week: 28, event: "Third trimester begins" },
    { week: 32, event: "Baby's bones harden" },
    { week: 36, event: "Baby is full-term soon" },
    { week: 40, event: "Due date" },
  ];

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link href="/">
          <Button variant="ghost" className="mb-8 text-slate-600 hover:text-primary">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Calculators
          </Button>
        </Link>

        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-pink-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Baby className="text-white h-10 w-10" />
            </div>
            <CardTitle className="text-3xl font-bold text-slate-800">Pregnancy Due Date Calculator</CardTitle>
            <CardDescription className="text-lg">
              Calculate your due date and track pregnancy milestones
            </CardDescription>
          </CardHeader>

          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Input Section */}
              <div className="space-y-6">
                {/* Last Menstrual Period */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">
                    First Day of Last Menstrual Period
                  </Label>
                  <Input
                    type="date"
                    value={lastPeriodDate}
                    onChange={(e) => setLastPeriodDate(e.target.value)}
                    className="mt-2"
                    max={new Date().toISOString().split('T')[0]}
                  />
                  <p className="text-xs text-slate-500 mt-1">
                    Select the first day of your last menstrual period
                  </p>
                </div>

                {/* Calculate Button */}
                <Button
                  onClick={handleCalculate}
                  className="w-full gradient-primary text-white py-3 rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
                >
                  <Calculator className="mr-2 h-5 w-5" />
                  Calculate Due Date
                </Button>

                {/* Important Note */}
                <div className="p-4 bg-yellow-50 rounded-xl border border-yellow-200">
                  <h4 className="font-semibold text-slate-700 mb-2 flex items-center">
                    <Lightbulb className="text-yellow-500 mr-2 h-4 w-4" />
                    Important Note
                  </h4>
                  <p className="text-sm text-slate-600">
                    This calculator provides estimates based on a 280-day pregnancy. 
                    Only about 5% of babies are born on their exact due date. 
                    Consult your healthcare provider for accurate pregnancy monitoring.
                  </p>
                </div>
              </div>

              {/* Results Section */}
              <div className="space-y-6">
                {result && (
                  <>
                    {/* Due Date */}
                    <div className="text-center p-6 bg-slate-50 rounded-2xl">
                      <h3 className="text-lg font-semibold text-slate-700 mb-2">Estimated Due Date</h3>
                      <div className="text-2xl font-bold text-pink-600 mb-2">
                        {formatDate(result.dueDate)}
                      </div>
                      <p className="text-sm text-slate-600">{result.daysRemaining} days remaining</p>
                    </div>

                    {/* Current Status */}
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-pink-50 rounded-xl border border-pink-200">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-pink-600">{result.weeksPregnant}</div>
                            <div className="text-sm text-slate-600">Weeks</div>
                          </div>
                        </div>
                        <div className="p-4 bg-purple-50 rounded-xl border border-purple-200">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-purple-600">{result.trimester}</div>
                            <div className="text-sm text-slate-600">Trimester</div>
                          </div>
                        </div>
                      </div>

                      {/* Trimester Info */}
                      <div className={`p-4 rounded-xl border ${getTrimesterInfo(result.trimester).color}`}>
                        <h4 className="font-semibold text-slate-700 mb-1">
                          {getTrimesterInfo(result.trimester).title}
                        </h4>
                        <p className="text-sm text-slate-600 mb-1">
                          {getTrimesterInfo(result.trimester).weeks}
                        </p>
                        <p className="text-sm text-slate-600">
                          {getTrimesterInfo(result.trimester).description}
                        </p>
                      </div>
                    </div>

                    {/* Milestones */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-slate-700">Pregnancy Milestones</h4>
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {milestones.map((milestone, index) => (
                          <div
                            key={index}
                            className={`flex items-center justify-between p-3 rounded-lg transition-all ${
                              result.weeksPregnant >= milestone.week
                                ? "bg-green-50 border border-green-200"
                                : result.weeksPregnant + 1 === milestone.week
                                ? "bg-blue-50 border border-blue-200 ring-2 ring-blue-300"
                                : "bg-gray-50 border border-gray-200"
                            }`}
                          >
                            <span className="text-sm font-medium text-slate-800">
                              Week {milestone.week}
                            </span>
                            <span className="text-sm text-slate-600">{milestone.event}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
