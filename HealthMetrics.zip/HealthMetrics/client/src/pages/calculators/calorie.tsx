import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Utensils, Calculator, Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import UnitToggle from "@/components/unit-toggle";
import { calculateBMR, calculateCalorieNeeds, convertHeight, convertWeight, convertCmToMeters } from "@/lib/calculations";
import type { CalorieResult } from "@/lib/calculations";

export default function CalorieCalculator() {
  const [isMetric, setIsMetric] = useState(true);
  const [height, setHeight] = useState("");
  const [heightFt, setHeightFt] = useState("");
  const [heightIn, setHeightIn] = useState("");
  const [weight, setWeight] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState<"male" | "female">("male");
  const [activityLevel, setActivityLevel] = useState("1.55");
  const [result, setResult] = useState<CalorieResult | null>(null);

  const activityLevels = [
    { value: "1.2", label: "Sedentary", description: "Little or no exercise" },
    { value: "1.375", label: "Light", description: "Light exercise 1-3 days/week" },
    { value: "1.55", label: "Moderate", description: "Moderate exercise 3-5 days/week" },
    { value: "1.725", label: "Active", description: "Hard exercise 6-7 days/week" },
    { value: "1.9", label: "Very Active", description: "Very hard exercise, physical job" },
  ];

  const handleCalculate = () => {
    let heightInMeters: number;
    let weightInKg: number;

    try {
      if (isMetric) {
        heightInMeters = convertCmToMeters(parseFloat(height));
        weightInKg = parseFloat(weight);
      } else {
        heightInMeters = convertHeight(parseFloat(heightFt), parseFloat(heightIn));
        weightInKg = convertWeight(parseFloat(weight));
      }

      const ageNum = parseFloat(age);

      if (heightInMeters > 0 && weightInKg > 0 && ageNum > 0) {
        const bmrResult = calculateBMR(weightInKg, heightInMeters, ageNum, gender);
        const calorieResult = calculateCalorieNeeds(bmrResult.bmr, parseFloat(activityLevel));
        setResult(calorieResult);
      } else {
        alert("Please enter valid height, weight, and age values.");
      }
    } catch (error) {
      alert("Please enter valid numeric values.");
    }
  };

  const goals = [
    { key: "extremeLoss", label: "Extreme Weight Loss", description: "2 lbs/week", color: "bg-red-50 border-red-200" },
    { key: "moderateLoss", label: "Moderate Weight Loss", description: "1 lb/week", color: "bg-orange-50 border-orange-200" },
    { key: "mildLoss", label: "Mild Weight Loss", description: "0.5 lb/week", color: "bg-yellow-50 border-yellow-200" },
    { key: "maintain", label: "Maintain Weight", description: "0 lb/week", color: "bg-green-50 border-green-200" },
    { key: "mildGain", label: "Mild Weight Gain", description: "0.5 lb/week", color: "bg-blue-50 border-blue-200" },
    { key: "moderateGain", label: "Moderate Weight Gain", description: "1 lb/week", color: "bg-indigo-50 border-indigo-200" },
    { key: "extremeGain", label: "Extreme Weight Gain", description: "2 lb/week", color: "bg-purple-50 border-purple-200" },
  ];

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link href="/">
          <Button variant="ghost" className="mb-8 text-slate-600 hover:text-primary">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Calculators
          </Button>
        </Link>

        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Utensils className="text-white h-10 w-10" />
            </div>
            <CardTitle className="text-3xl font-bold text-slate-800">Calorie Calculator</CardTitle>
            <CardDescription className="text-lg">
              Calculate daily calorie needs for your weight goals
            </CardDescription>
          </CardHeader>

          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Input Section */}
              <div className="space-y-6">
                <UnitToggle isMetric={isMetric} onToggle={setIsMetric} />

                {/* Gender Selection */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Gender</Label>
                  <Select value={gender} onValueChange={(value) => setGender(value as "male" | "female")}>
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Age Input */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Age</Label>
                  <div className="relative mt-2">
                    <Input
                      type="number"
                      placeholder="25"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      className="pr-16"
                    />
                    <span className="absolute right-4 top-3 text-slate-500 text-sm">years</span>
                  </div>
                </div>

                {/* Height Input */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Height</Label>
                  {isMetric ? (
                    <div className="relative mt-2">
                      <Input
                        type="number"
                        placeholder="175"
                        value={height}
                        onChange={(e) => setHeight(e.target.value)}
                        className="pr-12"
                      />
                      <span className="absolute right-4 top-3 text-slate-500 text-sm">cm</span>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-3 mt-2">
                      <div className="relative">
                        <Input
                          type="number"
                          placeholder="5"
                          value={heightFt}
                          onChange={(e) => setHeightFt(e.target.value)}
                          className="pr-8"
                        />
                        <span className="absolute right-3 top-3 text-slate-500 text-sm">ft</span>
                      </div>
                      <div className="relative">
                        <Input
                          type="number"
                          placeholder="9"
                          value={heightIn}
                          onChange={(e) => setHeightIn(e.target.value)}
                          className="pr-8"
                        />
                        <span className="absolute right-3 top-3 text-slate-500 text-sm">in</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Weight Input */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Weight</Label>
                  <div className="relative mt-2">
                    <Input
                      type="number"
                      placeholder={isMetric ? "70" : "154"}
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      className="pr-12"
                    />
                    <span className="absolute right-4 top-3 text-slate-500 text-sm">
                      {isMetric ? "kg" : "lbs"}
                    </span>
                  </div>
                </div>

                {/* Activity Level */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Activity Level</Label>
                  <Select value={activityLevel} onValueChange={setActivityLevel}>
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {activityLevels.map((level) => (
                        <SelectItem key={level.value} value={level.value}>
                          {level.label} - {level.description}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Calculate Button */}
                <Button
                  onClick={handleCalculate}
                  className="w-full gradient-primary text-white py-3 rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
                >
                  <Calculator className="mr-2 h-5 w-5" />
                  Calculate Calories
                </Button>
              </div>

              {/* Results Section */}
              <div className="space-y-6">
                {result && (
                  <>
                    {/* Calorie Goals */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-slate-700">Daily Calorie Goals</h4>
                      <div className="space-y-2">
                        {goals.map((goal) => (
                          <div
                            key={goal.key}
                            className={`flex items-center justify-between p-4 rounded-lg border ${goal.color}`}
                          >
                            <div>
                              <div className="text-sm font-medium text-slate-800">{goal.label}</div>
                              <div className="text-xs text-slate-600">{goal.description}</div>
                            </div>
                            <div className="text-lg font-semibold text-purple-600">
                              {Math.round(result[goal.key as keyof CalorieResult] as number)}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Health Tips */}
                    <div className="p-6 gradient-card rounded-2xl">
                      <h4 className="font-semibold text-slate-700 mb-3 flex items-center">
                        <Lightbulb className="text-yellow-500 mr-2 h-5 w-5" />
                        Calorie Tips
                      </h4>
                      <p className="text-sm text-slate-600 mb-2">
                        • A safe rate of weight loss is 1-2 pounds per week
                      </p>
                      <p className="text-sm text-slate-600 mb-2">
                        • Never go below 1200 calories (women) or 1500 calories (men) per day
                      </p>
                      <p className="text-sm text-slate-600">
                        • Focus on nutrient-dense foods for optimal health
                      </p>
                    </div>
                  </>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
