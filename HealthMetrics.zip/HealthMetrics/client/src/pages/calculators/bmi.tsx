import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Weight, Calculator, Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import UnitToggle from "@/components/unit-toggle";
import { calculateBMI, convertHeight, convertWeight, convertCmToMeters } from "@/lib/calculations";
import type { BMIResult } from "@/lib/calculations";

export default function BMICalculator() {
  const [isMetric, setIsMetric] = useState(true);
  const [height, setHeight] = useState("");
  const [heightFt, setHeightFt] = useState("");
  const [heightIn, setHeightIn] = useState("");
  const [weight, setWeight] = useState("");
  const [result, setResult] = useState<BMIResult | null>(null);

  const handleCalculate = () => {
    let heightInMeters: number;
    let weightInKg: number;

    try {
      if (isMetric) {
        heightInMeters = convertCmToMeters(parseFloat(height));
        weightInKg = parseFloat(weight);
      } else {
        heightInMeters = convertHeight(parseFloat(heightFt), parseFloat(heightIn));
        weightInKg = convertWeight(parseFloat(weight));
      }

      if (heightInMeters > 0 && weightInKg > 0) {
        const bmiResult = calculateBMI(heightInMeters, weightInKg);
        setResult(bmiResult);
      } else {
        alert("Please enter valid height and weight values.");
      }
    } catch (error) {
      alert("Please enter valid numeric values.");
    }
  };

  const bmiCategories = [
    { label: "Underweight", range: "< 18.5", color: "bg-blue-50 text-blue-800" },
    { label: "Normal", range: "18.5 - 24.9", color: "bg-green-50 text-green-800" },
    { label: "Overweight", range: "25.0 - 29.9", color: "bg-yellow-50 text-yellow-800" },
    { label: "Obese", range: "≥ 30.0", color: "bg-red-50 text-red-800" },
  ];

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link href="/">
          <Button variant="ghost" className="mb-8 text-slate-600 hover:text-primary">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Calculators
          </Button>
        </Link>

        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Weight className="text-white h-10 w-10" />
            </div>
            <CardTitle className="text-3xl font-bold text-slate-800">BMI Calculator</CardTitle>
            <CardDescription className="text-lg">
              Calculate your Body Mass Index and understand your health category
            </CardDescription>
          </CardHeader>

          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Input Section */}
              <div className="space-y-6">
                <UnitToggle isMetric={isMetric} onToggle={setIsMetric} />

                {/* Height Input */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Height</Label>
                  {isMetric ? (
                    <div className="relative mt-2">
                      <Input
                        type="number"
                        placeholder="175"
                        value={height}
                        onChange={(e) => setHeight(e.target.value)}
                        className="pr-12"
                      />
                      <span className="absolute right-4 top-3 text-slate-500 text-sm">cm</span>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-3 mt-2">
                      <div className="relative">
                        <Input
                          type="number"
                          placeholder="5"
                          value={heightFt}
                          onChange={(e) => setHeightFt(e.target.value)}
                          className="pr-8"
                        />
                        <span className="absolute right-3 top-3 text-slate-500 text-sm">ft</span>
                      </div>
                      <div className="relative">
                        <Input
                          type="number"
                          placeholder="9"
                          value={heightIn}
                          onChange={(e) => setHeightIn(e.target.value)}
                          className="pr-8"
                        />
                        <span className="absolute right-3 top-3 text-slate-500 text-sm">in</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Weight Input */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Weight</Label>
                  <div className="relative mt-2">
                    <Input
                      type="number"
                      placeholder={isMetric ? "70" : "154"}
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      className="pr-12"
                    />
                    <span className="absolute right-4 top-3 text-slate-500 text-sm">
                      {isMetric ? "kg" : "lbs"}
                    </span>
                  </div>
                </div>

                {/* Calculate Button */}
                <Button
                  onClick={handleCalculate}
                  className="w-full gradient-primary text-white py-3 rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
                >
                  <Calculator className="mr-2 h-5 w-5" />
                  Calculate BMI
                </Button>
              </div>

              {/* Results Section */}
              <div className="space-y-6">
                {result && (
                  <>
                    {/* BMI Score */}
                    <div className="text-center p-6 bg-slate-50 rounded-2xl">
                      <h3 className="text-lg font-semibold text-slate-700 mb-2">Your BMI</h3>
                      <div className="text-4xl font-bold text-primary mb-2">{result.bmi.toFixed(1)}</div>
                      <div className={`inline-flex items-center px-4 py-2 rounded-full text-sm font-medium ${result.categoryClass}`}>
                        <div className="w-3 h-3 rounded-full bg-current mr-2"></div>
                        {result.category}
                      </div>
                    </div>

                    {/* Health Tips */}
                    <div className="p-6 gradient-card rounded-2xl">
                      <h4 className="font-semibold text-slate-700 mb-3 flex items-center">
                        <Lightbulb className="text-yellow-500 mr-2 h-5 w-5" />
                        Health Tips
                      </h4>
                      <p className="text-sm text-slate-600">{result.tips}</p>
                    </div>
                  </>
                )}

                {/* BMI Chart */}
                <div className="space-y-3">
                  <h4 className="font-semibold text-slate-700">BMI Categories</h4>
                  <div className="space-y-2">
                    {bmiCategories.map((category, index) => (
                      <div
                        key={index}
                        className={`flex items-center justify-between p-3 rounded-lg ${category.color} ${
                          result?.category === category.label ? "ring-2 ring-primary" : ""
                        }`}
                      >
                        <span className="text-sm font-medium">{category.label}</span>
                        <span className="text-sm">{category.range}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
