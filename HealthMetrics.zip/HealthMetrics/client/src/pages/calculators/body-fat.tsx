import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Activity, Calculator, Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import UnitToggle from "@/components/unit-toggle";
import { calculateBodyFat, convertHeight, convertCmToMeters } from "@/lib/calculations";
import type { BodyFatResult } from "@/lib/calculations";

export default function BodyFatCalculator() {
  const [isMetric, setIsMetric] = useState(true);
  const [height, setHeight] = useState("");
  const [heightFt, setHeightFt] = useState("");
  const [heightIn, setHeightIn] = useState("");
  const [waist, setWaist] = useState("");
  const [neck, setNeck] = useState("");
  const [hip, setHip] = useState("");
  const [gender, setGender] = useState<"male" | "female">("male");
  const [result, setResult] = useState<BodyFatResult | null>(null);

  const handleCalculate = () => {
    let heightInMeters: number;

    try {
      if (isMetric) {
        heightInMeters = convertCmToMeters(parseFloat(height));
      } else {
        heightInMeters = convertHeight(parseFloat(heightFt), parseFloat(heightIn));
      }

      const waistMeasurement = parseFloat(waist);
      const neckMeasurement = parseFloat(neck);
      const hipMeasurement = gender === "female" ? parseFloat(hip) : undefined;

      if (heightInMeters > 0 && waistMeasurement > 0 && neckMeasurement > 0) {
        if (gender === "female" && !hipMeasurement) {
          alert("Hip measurement is required for female body fat calculation.");
          return;
        }

        // Convert measurements to cm if imperial
        const waistCm = isMetric ? waistMeasurement : waistMeasurement * 2.54;
        const neckCm = isMetric ? neckMeasurement : neckMeasurement * 2.54;
        const hipCm = hipMeasurement ? (isMetric ? hipMeasurement : hipMeasurement * 2.54) : undefined;

        const bodyFatResult = calculateBodyFat(waistCm, neckCm, heightInMeters, gender, hipCm);
        setResult(bodyFatResult);
      } else {
        alert("Please enter valid measurements.");
      }
    } catch (error) {
      alert("Please enter valid numeric values.");
    }
  };

  const maleCategories = [
    { label: "Essential Fat", range: "2-5%", color: "bg-red-50 text-red-800" },
    { label: "Athletic", range: "6-13%", color: "bg-green-50 text-green-800" },
    { label: "Fitness", range: "14-17%", color: "bg-blue-50 text-blue-800" },
    { label: "Average", range: "18-24%", color: "bg-yellow-50 text-yellow-800" },
    { label: "Obese", range: "25%+", color: "bg-red-50 text-red-800" },
  ];

  const femaleCategories = [
    { label: "Essential Fat", range: "10-13%", color: "bg-red-50 text-red-800" },
    { label: "Athletic", range: "14-20%", color: "bg-green-50 text-green-800" },
    { label: "Fitness", range: "21-24%", color: "bg-blue-50 text-blue-800" },
    { label: "Average", range: "25-31%", color: "bg-yellow-50 text-yellow-800" },
    { label: "Obese", range: "32%+", color: "bg-red-50 text-red-800" },
  ];

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link href="/">
          <Button variant="ghost" className="mb-8 text-slate-600 hover:text-primary">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Calculators
          </Button>
        </Link>

        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-amber-500 to-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Activity className="text-white h-10 w-10" />
            </div>
            <CardTitle className="text-3xl font-bold text-slate-800">Body Fat Calculator</CardTitle>
            <CardDescription className="text-lg">
              Calculate body fat percentage using the U.S. Navy method
            </CardDescription>
          </CardHeader>

          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Input Section */}
              <div className="space-y-6">
                <UnitToggle isMetric={isMetric} onToggle={setIsMetric} />

                {/* Gender Selection */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Gender</Label>
                  <Select value={gender} onValueChange={(value) => setGender(value as "male" | "female")}>
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Height Input */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Height</Label>
                  {isMetric ? (
                    <div className="relative mt-2">
                      <Input
                        type="number"
                        placeholder="175"
                        value={height}
                        onChange={(e) => setHeight(e.target.value)}
                        className="pr-12"
                      />
                      <span className="absolute right-4 top-3 text-slate-500 text-sm">cm</span>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-3 mt-2">
                      <div className="relative">
                        <Input
                          type="number"
                          placeholder="5"
                          value={heightFt}
                          onChange={(e) => setHeightFt(e.target.value)}
                          className="pr-8"
                        />
                        <span className="absolute right-3 top-3 text-slate-500 text-sm">ft</span>
                      </div>
                      <div className="relative">
                        <Input
                          type="number"
                          placeholder="9"
                          value={heightIn}
                          onChange={(e) => setHeightIn(e.target.value)}
                          className="pr-8"
                        />
                        <span className="absolute right-3 top-3 text-slate-500 text-sm">in</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Waist Input */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Waist Circumference</Label>
                  <div className="relative mt-2">
                    <Input
                      type="number"
                      placeholder={isMetric ? "80" : "32"}
                      value={waist}
                      onChange={(e) => setWaist(e.target.value)}
                      className="pr-12"
                    />
                    <span className="absolute right-4 top-3 text-slate-500 text-sm">
                      {isMetric ? "cm" : "in"}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">Measure at the narrowest point</p>
                </div>

                {/* Neck Input */}
                <div>
                  <Label className="text-sm font-medium text-slate-700">Neck Circumference</Label>
                  <div className="relative mt-2">
                    <Input
                      type="number"
                      placeholder={isMetric ? "37" : "15"}
                      value={neck}
                      onChange={(e) => setNeck(e.target.value)}
                      className="pr-12"
                    />
                    <span className="absolute right-4 top-3 text-slate-500 text-sm">
                      {isMetric ? "cm" : "in"}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">Measure just below the larynx</p>
                </div>

                {/* Hip Input (Female only) */}
                {gender === "female" && (
                  <div>
                    <Label className="text-sm font-medium text-slate-700">Hip Circumference</Label>
                    <div className="relative mt-2">
                      <Input
                        type="number"
                        placeholder={isMetric ? "95" : "38"}
                        value={hip}
                        onChange={(e) => setHip(e.target.value)}
                        className="pr-12"
                      />
                      <span className="absolute right-4 top-3 text-slate-500 text-sm">
                        {isMetric ? "cm" : "in"}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">Measure at the largest circumference</p>
                  </div>
                )}

                {/* Calculate Button */}
                <Button
                  onClick={handleCalculate}
                  className="w-full gradient-primary text-white py-3 rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
                >
                  <Calculator className="mr-2 h-5 w-5" />
                  Calculate Body Fat
                </Button>
              </div>

              {/* Results Section */}
              <div className="space-y-6">
                {result && (
                  <>
                    {/* Body Fat Score */}
                    <div className="text-center p-6 bg-slate-50 rounded-2xl">
                      <h3 className="text-lg font-semibold text-slate-700 mb-2">Your Body Fat</h3>
                      <div className="text-4xl font-bold text-amber-600 mb-2">
                        {result.bodyFat.toFixed(1)}%
                      </div>
                      <div className={`inline-flex items-center px-4 py-2 rounded-full text-sm font-medium ${result.categoryClass}`}>
                        <div className="w-3 h-3 rounded-full bg-current mr-2"></div>
                        {result.category}
                      </div>
                    </div>

                    {/* Health Tips */}
                    <div className="p-6 gradient-card rounded-2xl">
                      <h4 className="font-semibold text-slate-700 mb-3 flex items-center">
                        <Lightbulb className="text-yellow-500 mr-2 h-5 w-5" />
                        Health Tips
                      </h4>
                      <p className="text-sm text-slate-600">{result.tips}</p>
                    </div>
                  </>
                )}

                {/* Body Fat Categories */}
                <div className="space-y-3">
                  <h4 className="font-semibold text-slate-700">
                    Body Fat Categories ({gender === "male" ? "Male" : "Female"})
                  </h4>
                  <div className="space-y-2">
                    {(gender === "male" ? maleCategories : femaleCategories).map((category, index) => (
                      <div
                        key={index}
                        className={`flex items-center justify-between p-3 rounded-lg ${category.color} ${
                          result?.category === category.label ? "ring-2 ring-amber-500" : ""
                        }`}
                      >
                        <span className="text-sm font-medium">{category.label}</span>
                        <span className="text-sm">{category.range}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
