import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, User, Calculator, FileText, Plus, History, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import HealthReport from "@/components/health-report";
import { calculateBMI, calculateBMR, calculateBodyFat, calculateIdealWeight, calculateWaterIntake, calculateHeartRateZones } from "@/lib/calculations";
import type { HealthAssessment, InsertHealthAssessment } from "@shared/schema";

interface HealthData {
  bmi?: number;
  bmr?: number;
  bodyFat?: number;
  waterIntake?: number;
  idealWeight?: number;
  heartRateMax?: number;
  calories?: number;
  height?: number;
  weight?: number;
  age?: number;
  gender?: "male" | "female";
}

export default function HealthDashboard() {
  const [userName, setUserName] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [healthData, setHealthData] = useState<HealthData>({});
  const [showReport, setShowReport] = useState(false);
  const [savedAssessmentId, setSavedAssessmentId] = useState<number | null>(null);
  
  const queryClient = useQueryClient();

  // Form states for quick calculations
  const [quickCalcData, setQuickCalcData] = useState({
    height: "",
    weight: "",
    age: "",
    gender: "male" as "male" | "female",
    waist: "",
    neck: "",
    hip: "",
    restingHR: "60",
  });

  // Fetch user's assessment history
  const { data: assessmentHistory, isLoading: historyLoading } = useQuery({
    queryKey: ['/api/health-assessments/email', userEmail],
    queryFn: () => apiRequest({ 
      url: `/api/health-assessments/email/${encodeURIComponent(userEmail)}`,
      on401: "returnNull"
    }),
    enabled: !!userEmail,
  });

  // Mutation to save health assessment
  const saveAssessmentMutation = useMutation({
    mutationFn: (assessmentData: InsertHealthAssessment) =>
      apiRequest({
        url: '/api/health-assessments',
        method: 'POST',
        body: assessmentData,
        on401: "throw"
      }),
    onSuccess: (savedAssessment) => {
      setSavedAssessmentId(savedAssessment.id);
      queryClient.invalidateQueries({ queryKey: ['/api/health-assessments/email', userEmail] });
    },
  });

  const runAllCalculations = () => {
    if (!quickCalcData.height || !quickCalcData.weight || !quickCalcData.age) {
      alert("Please fill in height, weight, and age for comprehensive analysis.");
      return;
    }

    const heightM = parseFloat(quickCalcData.height) / 100; // Convert cm to meters
    const weightKg = parseFloat(quickCalcData.weight);
    const ageNum = parseFloat(quickCalcData.age);
    const restingHRNum = parseFloat(quickCalcData.restingHR);

    const results: HealthData = {
      height: parseFloat(quickCalcData.height),
      weight: weightKg,
      age: ageNum,
      gender: quickCalcData.gender,
    };

    try {
      // BMI Calculation
      const bmiResult = calculateBMI(heightM, weightKg);
      results.bmi = bmiResult.bmi;

      // BMR Calculation
      const bmrResult = calculateBMR(weightKg, heightM, ageNum, quickCalcData.gender);
      results.bmr = bmrResult.bmr;
      results.calories = bmrResult.calories.moderate; // Use moderate activity level

      // Water Intake Calculation
      const waterResult = calculateWaterIntake(weightKg, 60); // Assume 60 min daily activity
      results.waterIntake = waterResult.daily;

      // Ideal Weight Calculation
      const idealWeightResult = calculateIdealWeight(heightM, quickCalcData.gender);
      results.idealWeight = idealWeightResult.robinson;

      // Heart Rate Calculation
      const heartRateResult = calculateHeartRateZones(ageNum, restingHRNum);
      results.heartRateMax = heartRateResult.maxHR;

      // Body Fat Calculation (if measurements provided)
      if (quickCalcData.waist && quickCalcData.neck) {
        const waistCm = parseFloat(quickCalcData.waist);
        const neckCm = parseFloat(quickCalcData.neck);
        const hipCm = quickCalcData.gender === "female" && quickCalcData.hip ? parseFloat(quickCalcData.hip) : undefined;

        if (quickCalcData.gender === "female" && !hipCm) {
          alert("Hip measurement is required for female body fat calculation.");
        } else {
          const bodyFatResult = calculateBodyFat(waistCm, neckCm, heightM, quickCalcData.gender, hipCm);
          results.bodyFat = bodyFatResult.bodyFat;
        }
      }

      setHealthData(results);
      setShowReport(true);

      // Save to database if user provided email
      if (userEmail) {
        const assessmentData: InsertHealthAssessment = {
          userName: userName || null,
          email: userEmail,
          height: parseFloat(quickCalcData.height),
          weight: parseFloat(quickCalcData.weight),
          age: parseInt(quickCalcData.age),
          gender: quickCalcData.gender,
          waist: quickCalcData.waist ? parseFloat(quickCalcData.waist) : null,
          neck: quickCalcData.neck ? parseFloat(quickCalcData.neck) : null,
          hip: quickCalcData.hip ? parseFloat(quickCalcData.hip) : null,
          restingHeartRate: parseInt(quickCalcData.restingHR),
          activityLevel: "moderate",
          bmi: results.bmi,
          bmr: results.bmr,
          bodyFat: results.bodyFat,
          waterIntake: results.waterIntake,
          idealWeight: results.idealWeight,
          heartRateMax: results.heartRateMax,
          dailyCalories: results.calories,
          bmiCategory: results.bmi < 18.5 ? "Underweight" : results.bmi < 25 ? "Normal" : results.bmi < 30 ? "Overweight" : "Obese",
          bodyFatCategory: results.bodyFat ? (results.bodyFat < 15 ? "Athletic" : results.bodyFat < 25 ? "Fitness" : "Average") : null,
        };

        saveAssessmentMutation.mutate(assessmentData);
      }
    } catch (error) {
      alert("Error calculating health metrics. Please check your inputs.");
      console.error(error);
    }
  };

  const loadPreviousAssessment = (assessment: HealthAssessment) => {
    // Load assessment data into form
    setQuickCalcData({
      height: assessment.height?.toString() || "",
      weight: assessment.weight?.toString() || "",
      age: assessment.age?.toString() || "",
      gender: (assessment.gender as "male" | "female") || "male",
      waist: assessment.waist?.toString() || "",
      neck: assessment.neck?.toString() || "",
      hip: assessment.hip?.toString() || "",
      restingHR: assessment.restingHeartRate?.toString() || "60",
    });

    // Load calculated results
    const results: HealthData = {
      bmi: assessment.bmi || undefined,
      bmr: assessment.bmr || undefined,
      bodyFat: assessment.bodyFat || undefined,
      waterIntake: assessment.waterIntake || undefined,
      idealWeight: assessment.idealWeight || undefined,
      heartRateMax: assessment.heartRateMax || undefined,
      calories: assessment.dailyCalories || undefined,
      height: assessment.height || undefined,
      weight: assessment.weight || undefined,
      age: assessment.age || undefined,
      gender: (assessment.gender as "male" | "female") || undefined,
    };

    setHealthData(results);
    setShowReport(true);
    setSavedAssessmentId(assessment.id);
  };

  const quickCalculators = [
    {
      title: "BMI Calculator",
      href: "/calculator/bmi",
      description: "Calculate Body Mass Index",
      icon: "📊",
    },
    {
      title: "BMR Calculator", 
      href: "/calculator/bmr",
      description: "Basal Metabolic Rate",
      icon: "🔥",
    },
    {
      title: "Body Fat Calculator",
      href: "/calculator/body-fat", 
      description: "Body fat percentage",
      icon: "📏",
    },
    {
      title: "Water Calculator",
      href: "/calculator/water",
      description: "Daily water intake",
      icon: "💧",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link href="/">
          <Button variant="ghost" className="mb-8 text-slate-600 hover:text-primary">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
        </Link>

        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-slate-800 mb-4">Health Dashboard</h1>
          <p className="text-lg text-slate-600">Complete health assessment with personalized report generation</p>
        </div>

        <Tabs defaultValue="assessment" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="assessment">Health Assessment</TabsTrigger>
            <TabsTrigger value="history" disabled={!userEmail}>Assessment History</TabsTrigger>
            <TabsTrigger value="calculators">Individual Calculators</TabsTrigger>
            <TabsTrigger value="report" disabled={!showReport}>Health Report</TabsTrigger>
          </TabsList>

          {/* Health Assessment Tab */}
          <TabsContent value="assessment" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-6 w-6 text-primary" />
                  Personal Information
                </CardTitle>
                <CardDescription>
                  Enter your details for a comprehensive health analysis
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* User Name */}
                <div>
                  <Label htmlFor="userName">Your Name (Optional)</Label>
                  <Input
                    id="userName"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="Enter your name for personalized report"
                    className="mt-2"
                  />
                </div>

                {/* Basic Measurements */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      value={quickCalcData.height}
                      onChange={(e) => setQuickCalcData(prev => ({ ...prev, height: e.target.value }))}
                      placeholder="175"
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="weight">Weight (kg)</Label>
                    <Input
                      id="weight"
                      type="number"
                      value={quickCalcData.weight}
                      onChange={(e) => setQuickCalcData(prev => ({ ...prev, weight: e.target.value }))}
                      placeholder="70"
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="age">Age (years)</Label>
                    <Input
                      id="age"
                      type="number"
                      value={quickCalcData.age}
                      onChange={(e) => setQuickCalcData(prev => ({ ...prev, age: e.target.value }))}
                      placeholder="25"
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="gender">Gender</Label>
                    <select
                      id="gender"
                      value={quickCalcData.gender}
                      onChange={(e) => setQuickCalcData(prev => ({ ...prev, gender: e.target.value as "male" | "female" }))}
                      className="mt-2 w-full px-3 py-2 border border-slate-300 rounded-md bg-white"
                    >
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                    </select>
                  </div>
                </div>

                {/* Body Measurements (Optional) */}
                <div className="border-t pt-6">
                  <h3 className="text-lg font-semibold mb-4">Body Measurements (Optional - for body fat calculation)</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="waist">Waist Circumference (cm)</Label>
                      <Input
                        id="waist"
                        type="number"
                        value={quickCalcData.waist}
                        onChange={(e) => setQuickCalcData(prev => ({ ...prev, waist: e.target.value }))}
                        placeholder="80"
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="neck">Neck Circumference (cm)</Label>
                      <Input
                        id="neck"
                        type="number"
                        value={quickCalcData.neck}
                        onChange={(e) => setQuickCalcData(prev => ({ ...prev, neck: e.target.value }))}
                        placeholder="37"
                        className="mt-2"
                      />
                    </div>
                    {quickCalcData.gender === "female" && (
                      <div>
                        <Label htmlFor="hip">Hip Circumference (cm)</Label>
                        <Input
                          id="hip"
                          type="number"
                          value={quickCalcData.hip}
                          onChange={(e) => setQuickCalcData(prev => ({ ...prev, hip: e.target.value }))}
                          placeholder="95"
                          className="mt-2"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Generate Report Button */}
                <div className="text-center">
                  <Button
                    onClick={runAllCalculations}
                    size="lg"
                    className="gradient-primary text-white px-8 py-4 rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
                  >
                    <FileText className="mr-2 h-5 w-5" />
                    Generate Complete Health Report
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Individual Calculators Tab */}
          <TabsContent value="calculators">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {quickCalculators.map((calc, index) => (
                <Link key={index} href={calc.href}>
                  <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
                    <CardHeader className="text-center">
                      <div className="text-4xl mb-2">{calc.icon}</div>
                      <CardTitle className="text-lg">{calc.title}</CardTitle>
                      <CardDescription>{calc.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button variant="outline" className="w-full">
                        <Calculator className="mr-2 h-4 w-4" />
                        Calculate
                      </Button>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>More Calculators</CardTitle>
                <CardDescription>Access our complete suite of health assessment tools</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Link href="/calculator/ideal-weight">
                    <Button variant="outline" className="w-full">Ideal Weight</Button>
                  </Link>
                  <Link href="/calculator/calorie">
                    <Button variant="outline" className="w-full">Calorie Needs</Button>
                  </Link>
                  <Link href="/calculator/pregnancy">
                    <Button variant="outline" className="w-full">Pregnancy</Button>
                  </Link>
                  <Link href="/calculator/heart-rate">
                    <Button variant="outline" className="w-full">Heart Rate Zones</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Health Report Tab */}
          <TabsContent value="report">
            {showReport ? (
              <HealthReport 
                healthData={healthData} 
                userName={userName || "User"} 
              />
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <FileText className="h-16 w-16 text-slate-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-slate-600 mb-2">No Report Generated</h3>
                  <p className="text-slate-500">Complete the health assessment to generate your personalized report.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}