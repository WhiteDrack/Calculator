export interface BMIResult {
  bmi: number;
  category: string;
  categoryClass: string;
  tips: string;
}

export interface BMRResult {
  bmr: number;
  calories: {
    sedentary: number;
    light: number;
    moderate: number;
    active: number;
    veryActive: number;
  };
}

export interface CalorieResult {
  maintain: number;
  mildLoss: number;
  moderateLoss: number;
  extremeLoss: number;
  mildGain: number;
  moderateGain: number;
  extremeGain: number;
}

export interface IdealWeightResult {
  robinson: number;
  miller: number;
  devine: number;
  hamwi: number;
  healthy: { min: number; max: number };
}

export interface BodyFatResult {
  bodyFat: number;
  category: string;
  categoryClass: string;
  tips: string;
}

export interface WaterResult {
  daily: number;
  hourly: number;
  tips: string;
}

export interface PregnancyResult {
  dueDate: Date;
  weeksPregnant: number;
  trimester: number;
  daysRemaining: number;
}

export interface HeartRateResult {
  maxHR: number;
  zones: {
    warmup: { min: number; max: number };
    fatBurn: { min: number; max: number };
    aerobic: { min: number; max: number };
    anaerobic: { min: number; max: number };
    redline: { min: number; max: number };
  };
}

export const calculateBMI = (height: number, weight: number): BMIResult => {
  const bmi = weight / (height * height);
  
  let category: string;
  let categoryClass: string;
  let tips: string;

  if (bmi < 18.5) {
    category = 'Underweight';
    categoryClass = 'bg-blue-100 text-blue-800';
    tips = 'Your BMI indicates you are underweight. Consider consulting with a healthcare provider about healthy weight gain strategies.';
  } else if (bmi < 25) {
    category = 'Normal Weight';
    categoryClass = 'bg-green-100 text-green-800';
    tips = 'Your BMI indicates a normal weight. Maintain your current lifestyle with regular exercise and a balanced diet.';
  } else if (bmi < 30) {
    category = 'Overweight';
    categoryClass = 'bg-yellow-100 text-yellow-800';
    tips = 'Your BMI indicates you are overweight. Consider adopting a healthier diet and increasing physical activity.';
  } else {
    category = 'Obese';
    categoryClass = 'bg-red-100 text-red-800';
    tips = 'Your BMI indicates obesity. Please consult with a healthcare provider for personalized advice and support.';
  }

  return { bmi, category, categoryClass, tips };
};

export const calculateBMR = (weight: number, height: number, age: number, gender: 'male' | 'female'): BMRResult => {
  // Mifflin-St Jeor Equation
  let bmr: number;
  if (gender === 'male') {
    bmr = (10 * weight) + (6.25 * height * 100) - (5 * age) + 5;
  } else {
    bmr = (10 * weight) + (6.25 * height * 100) - (5 * age) - 161;
  }

  const calories = {
    sedentary: bmr * 1.2,
    light: bmr * 1.375,
    moderate: bmr * 1.55,
    active: bmr * 1.725,
    veryActive: bmr * 1.9
  };

  return { bmr, calories };
};

export const calculateCalorieNeeds = (bmr: number, activityLevel: number): CalorieResult => {
  const maintain = bmr * activityLevel;
  
  return {
    maintain,
    mildLoss: maintain - 250,
    moderateLoss: maintain - 500,
    extremeLoss: maintain - 750,
    mildGain: maintain + 250,
    moderateGain: maintain + 500,
    extremeGain: maintain + 750
  };
};

export const calculateIdealWeight = (height: number, gender: 'male' | 'female'): IdealWeightResult => {
  const heightCm = height * 100;
  const heightIn = heightCm / 2.54;
  
  // Robinson Formula
  const robinson = gender === 'male' 
    ? 52 + (1.9 * ((heightIn - 60)))
    : 49 + (1.7 * ((heightIn - 60)));
    
  // Miller Formula  
  const miller = gender === 'male'
    ? 56.2 + (1.41 * ((heightIn - 60)))
    : 53.1 + (1.36 * ((heightIn - 60)));
    
  // Devine Formula
  const devine = gender === 'male'
    ? 50 + (2.3 * ((heightIn - 60)))
    : 45.5 + (2.3 * ((heightIn - 60)));
    
  // Hamwi Formula
  const hamwi = gender === 'male'
    ? 48 + (2.7 * ((heightIn - 60)))
    : 45.5 + (2.2 * ((heightIn - 60)));

  // Healthy BMI range (18.5-24.9)
  const healthy = {
    min: 18.5 * (height * height),
    max: 24.9 * (height * height)
  };

  return { robinson, miller, devine, hamwi, healthy };
};

export const calculateBodyFat = (waist: number, neck: number, height: number, gender: 'male' | 'female', hip?: number): BodyFatResult => {
  let bodyFat: number;
  
  if (gender === 'male') {
    bodyFat = 495 / (1.0324 - 0.19077 * Math.log10(waist - neck) + 0.15456 * Math.log10(height * 100)) - 450;
  } else {
    if (!hip) throw new Error('Hip measurement required for female body fat calculation');
    bodyFat = 495 / (1.29579 - 0.35004 * Math.log10(waist + hip - neck) + 0.22100 * Math.log10(height * 100)) - 450;
  }

  let category: string;
  let categoryClass: string;
  let tips: string;

  if (gender === 'male') {
    if (bodyFat < 6) {
      category = 'Essential Fat';
      categoryClass = 'bg-red-100 text-red-800';
      tips = 'Essential fat level. This is very low and may not be healthy long-term.';
    } else if (bodyFat < 14) {
      category = 'Athletic';
      categoryClass = 'bg-green-100 text-green-800';
      tips = 'Athletic body fat level. Excellent for performance and health.';
    } else if (bodyFat < 18) {
      category = 'Fitness';
      categoryClass = 'bg-blue-100 text-blue-800';
      tips = 'Good fitness level. Maintain with regular exercise.';
    } else if (bodyFat < 25) {
      category = 'Average';
      categoryClass = 'bg-yellow-100 text-yellow-800';
      tips = 'Average body fat level. Consider increasing exercise to improve health.';
    } else {
      category = 'Obese';
      categoryClass = 'bg-red-100 text-red-800';
      tips = 'High body fat level. Consider consulting a healthcare provider.';
    }
  } else {
    if (bodyFat < 14) {
      category = 'Essential Fat';
      categoryClass = 'bg-red-100 text-red-800';
      tips = 'Essential fat level. This is very low and may not be healthy long-term.';
    } else if (bodyFat < 21) {
      category = 'Athletic';
      categoryClass = 'bg-green-100 text-green-800';
      tips = 'Athletic body fat level. Excellent for performance and health.';
    } else if (bodyFat < 25) {
      category = 'Fitness';
      categoryClass = 'bg-blue-100 text-blue-800';
      tips = 'Good fitness level. Maintain with regular exercise.';
    } else if (bodyFat < 32) {
      category = 'Average';
      categoryClass = 'bg-yellow-100 text-yellow-800';
      tips = 'Average body fat level. Consider increasing exercise to improve health.';
    } else {
      category = 'Obese';
      categoryClass = 'bg-red-100 text-red-800';
      tips = 'High body fat level. Consider consulting a healthcare provider.';
    }
  }

  return { bodyFat, category, categoryClass, tips };
};

export const calculateWaterIntake = (weight: number, activityMinutes: number = 0, climate: 'normal' | 'hot' | 'humid' = 'normal'): WaterResult => {
  // Base calculation: 35ml per kg of body weight
  let daily = weight * 35;
  
  // Add for physical activity (12ml per minute)
  daily += activityMinutes * 12;
  
  // Adjust for climate
  if (climate === 'hot') daily *= 1.16;
  if (climate === 'humid') daily *= 1.13;
  
  const hourly = daily / 16; // Assuming 16 waking hours
  
  let tips = `Drink water consistently throughout the day. `;
  if (activityMinutes > 60) {
    tips += `Since you exercise regularly, ensure you drink extra water before, during, and after workouts. `;
  }
  if (climate !== 'normal') {
    tips += `Hot and humid weather increases fluid needs - monitor your hydration closely.`;
  }

  return { daily, hourly, tips };
};

export const calculatePregnancy = (lastPeriod: Date): PregnancyResult => {
  const today = new Date();
  const timeDiff = today.getTime() - lastPeriod.getTime();
  const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
  
  // Due date is 280 days (40 weeks) from last menstrual period
  const dueDate = new Date(lastPeriod);
  dueDate.setDate(dueDate.getDate() + 280);
  
  const weeksPregnant = Math.floor(daysDiff / 7);
  const trimester = weeksPregnant <= 12 ? 1 : weeksPregnant <= 27 ? 2 : 3;
  
  const dueDateDiff = dueDate.getTime() - today.getTime();
  const daysRemaining = Math.max(0, Math.ceil(dueDateDiff / (1000 * 3600 * 24)));

  return { dueDate, weeksPregnant, trimester, daysRemaining };
};

export const calculateHeartRateZones = (age: number, restingHR: number = 60): HeartRateResult => {
  const maxHR = 220 - age;
  
  // Karvonen method using heart rate reserve
  const hrReserve = maxHR - restingHR;
  
  const zones = {
    warmup: {
      min: Math.round(restingHR + (hrReserve * 0.50)),
      max: Math.round(restingHR + (hrReserve * 0.60))
    },
    fatBurn: {
      min: Math.round(restingHR + (hrReserve * 0.60)),
      max: Math.round(restingHR + (hrReserve * 0.70))
    },
    aerobic: {
      min: Math.round(restingHR + (hrReserve * 0.70)),
      max: Math.round(restingHR + (hrReserve * 0.80))
    },
    anaerobic: {
      min: Math.round(restingHR + (hrReserve * 0.80)),
      max: Math.round(restingHR + (hrReserve * 0.90))
    },
    redline: {
      min: Math.round(restingHR + (hrReserve * 0.90)),
      max: maxHR
    }
  };

  return { maxHR, zones };
};

export const convertHeight = (feet: number, inches: number): number => {
  return ((feet * 12) + inches) * 0.0254; // Convert to meters
};

export const convertWeight = (pounds: number): number => {
  return pounds * 0.453592; // Convert to kg
};

export const convertCmToMeters = (cm: number): number => {
  return cm / 100;
};
